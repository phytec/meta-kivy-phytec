import os

path_demo = os.path.dirname(__file__)
"""Path to DemoKivy package directory."""

# uix_path = os.path.join(path, "uix")
